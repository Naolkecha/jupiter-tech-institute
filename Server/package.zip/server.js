const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require("dotenv").config();
const app = express();
const port = 3000;

const cors = require('cors');

app.use(cors({
  origin: 'http://localhost:3001',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Database connection
const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: 'Naol@24!',
  database: 'students',
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;lljlalkjkgakljkgjallkkjjkjfkjkjfkdjglkdsglksjkgflksjgkdl
  }
  console.log('Connected to MySQL database');
});

// Parse JSON data in request body
app.use(bodyParser.json());

// Define login route
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  // Validate username and password
  if (!username || !password) {
    res.status(400).send('Missing username or password');
    return;
  }

  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);

  // Check username and password against database
  const query = `SELECT * FROM admin WHERE username = ? AND password = ?`;
  connection.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('Error querying database:', err);
      res.status(500).send('Internal server error');
      return;
    }

    if (results.length > 0) {
      // Login successful
      // Generate a JWT token
      const token = jwt.sign({ username }, process.env.JWT_SECRET, { expiresIn: '1h' });

      res.status(200).send({ success: true, token });
    } else {
      // Invalid credentialskkkkk
      res.status(401).send('Invalid username or password');
      console.log("not correct")
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
